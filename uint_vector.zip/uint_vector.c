/********************************************************************************
* uint_vector_c: Inneh�ller definitioner av associerade funktioner f�r strukten
*                uint_vector, som anv�nds f�r lagring av osignerade heltal.
********************************************************************************/
#include "uint_vector.h"

/********************************************************************************
* uint_vector_init: Initierar ny vektor f�r lagring av osignerade heltal.
*
*                   - self: Pekare till vektorn som ska initieras.
********************************************************************************/
void uint_vector_init(uint_vector_t* self)
{
   self->data = 0;
   self->size = 0;
   return;
}

/********************************************************************************
* uint_vector_clear: T�mmer angiven vektor.
*
*                    - self: Pekare till vektorn som ska t�mmas.
********************************************************************************/
void uint_vector_clear(uint_vector_t* self)
{
   free(self->data);
   self->data = 0;
   self->size = 0;
   return;
}

/********************************************************************************
* uint_vector_push: L�gger till ett osignerat heltal l�ngst bak i angiven vektor.
*                   Om till�gget lyckas returneras 0, annars returneras felkod 1.
*
*                    - self: Pekare till vektorn som ska tilldelas talet.
*                    - num : Det nya tal som ska l�ggas till i vektorn.
********************************************************************************/
int uint_vector_push(uint_vector_t* self,
                     const unsigned int num)
{
   unsigned int* copy = (unsigned int*)realloc(self->data, sizeof(unsigned int) * (self->size + 1));
   if (!copy) return 1;
   copy[self->size++] = num;
   self->data = copy;
   return 0;
}

/********************************************************************************
* uint_vector_pop: Tar bort eventuellt sista element i vektorn. Om allokeringen
*                  mot f�rmodan misslyckas returneras felkod 1, annars
*                  annars returneras 0.
*
*                  - self: Pekare till vektorn vars sista element ska tas bort.
********************************************************************************/
int uint_vector_pop(uint_vector_t* self)
{
   if (self->size <= 1)
   {
      uint_vector_clear(self);
      return 0;
   }
   else
   {
      unsigned int* copy = (unsigned int*)realloc(self->data, sizeof(unsigned int) * (self->size - 1));
      if (!copy) return 1;
      self->data = copy;
      self->size--;
      return 0;
   }
}

/********************************************************************************
* uint_vector_print: Skriver ut inneh�llet lagrat i angiven vektor via angiven
*                    utstr�m, d�r standardutenhet stdout anv�nds som default
*                    f�r utskrift i terminalen.
*
*                    - self   : Pekare till vektorn vars inneh�ll ska skrivas ut.
*                    - ostream: Pekare till angiven utstr�m (default = stdout).
********************************************************************************/
void uint_vector_print(const uint_vector_t* self,
                       FILE* ostream)
{
   if (!ostream) ostream = stdout;
   fprintf(ostream, "------------------------------------------------------------------------------------\n");

   for (size_t i = 0; i < self->size; ++i)
   {
      fprintf(ostream, "%u\n", self->data[i]);
   }

   fprintf(ostream, "------------------------------------------------------------------------------------\n\n");
   return;
}