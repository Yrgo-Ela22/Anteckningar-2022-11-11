/********************************************************************************
* main.c: Implementering av dynamisk vektor f�r lagring av osignerade heltal.
********************************************************************************/
#include "uint_vector.h"

/********************************************************************************
* main: Deklarerar en ny vektor f�r lagring av osignerade heltal. Vektorn fylls
*       med heltal 0 - 5, f�ljt av utskrift i terminalen. Sedan raderas det
*       sista talet i vektorn, f�ljt av ytterligare en utskrift. Innan
*       programmet avslutas s� frig�rs det allokerade minnet, annars frig�rs
*       inte det f�rr�n vi startar om datorn.
********************************************************************************/
int main(void)
{
   uint_vector_t v1;
   uint_vector_init(&v1);

   for (unsigned int i = 0; i < 5; ++i)
   {
      uint_vector_push(&v1, i);
   }

   uint_vector_print(&v1, 0);

   uint_vector_pop(&v1);
   uint_vector_print(&v1, 0);

   uint_vector_clear(&v1);
   return 0;
}