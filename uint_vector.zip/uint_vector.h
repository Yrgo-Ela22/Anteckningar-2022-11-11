/********************************************************************************
* uint_vector.h: Inneh�ller funktionalitet f�r lagring av osignerade heltal
*                via dynamiska arrayer, implementerat via strukten uint_vector
*                samt associerade funktioner.
********************************************************************************/
#ifndef UINT_VECTOR_H_
#define UINT_VECTOR_H_

/* Inkluderingsdirektiv: */
#include <stdio.h>  /* printf, FILE* med mera. */
#include <stdlib.h> /* malloc, realloc och free. */

/********************************************************************************
* uint_vector: Strukt f�r lagring av osignerade heltal i en dynamisk array.
********************************************************************************/
typedef struct uint_vector
{
   unsigned int* data; /* Pekare till dynamiskt f�lt inneh�llande heltal. */
   size_t size;        /* Vektorns storlek, dvs. antalet lagrade heltal. */
} uint_vector_t;

/********************************************************************************
* uint_vector_init: Initierar ny vektor f�r lagring av osignerade heltal.
* 
*                   - self: Pekare till vektorn som ska initieras.
********************************************************************************/
void uint_vector_init(uint_vector_t* self);

/********************************************************************************
* uint_vector_clear: T�mmer angiven vektor.
*
*                    - self: Pekare till vektorn som ska t�mmas.
********************************************************************************/
void uint_vector_clear(uint_vector_t* self);

/********************************************************************************
* uint_vector_push: L�gger till ett osignerat heltal l�ngst bak i angiven vektor.
*                   Om till�gget lyckas returneras 0, annars returneras felkod 1.
*
*                    - self: Pekare till vektorn som ska tilldelas talet.
*                    - num : Det nya tal som ska l�ggas till i vektorn.
********************************************************************************/
int uint_vector_push(uint_vector_t* self,
                     const unsigned int num);

/********************************************************************************
* uint_vector_pop: Tar bort eventuellt sista element i vektorn. Om allokeringen
*                  mot f�rmodan misslyckas returneras felkod 1, annars
*                  annars returneras 0.
*
*                  - self: Pekare till vektorn vars sista element ska tas bort.
********************************************************************************/
int uint_vector_pop(uint_vector_t* self);

/********************************************************************************
* uint_vector_print: Skriver ut inneh�llet lagrat i angiven vektor via angiven
*                    utstr�m, d�r standardutenhet stdout anv�nds som default
*                    f�r utskrift i terminalen.
*
*                    - self   : Pekare till vektorn vars inneh�ll ska skrivas ut.
*                    - ostream: Pekare till angiven utstr�m (default = stdout).
********************************************************************************/
void uint_vector_print(const uint_vector_t* self,
                       FILE* ostream);

#endif /* UINT_VECTOR_H_ */